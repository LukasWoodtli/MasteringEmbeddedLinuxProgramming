int add_ints(int n1, int n2);
int multiply_ints(int n1, int n2);
